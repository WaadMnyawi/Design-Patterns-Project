/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Stage2;

/**
 *
 * @author lunas
 */
public class Stage2 {

    public static void main(String[] args) {

        // Create a Customer object
        Customer customer = new Customer("Waad Mnyawi", "Waad@email.com", "0508436103");

        // Create a TourPackage object
        TourPackage tourPackage = new TourPackage("Adventure in the Alps", "Explore the majestic mountains of Switzerland", 1999.99);

        // Use BookingBuilder to create a Booking object with a fluent interface
        Booking booking = new ConcreteBookingBuilder()
                .customer(customer)
                .tourPackage(tourPackage)
                .date("2024-06-15")
                .duration(7)
                .build();

        // Display the booking information
        System.out.println("Booking Details:");
        System.out.println(booking);
    }
}