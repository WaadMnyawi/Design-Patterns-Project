/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Stage2;

/**
 *
 * @author lunas
 */

public interface BookingBuilder {
    BookingBuilder customer(Customer customer);
    BookingBuilder tourPackage(TourPackage tourPackage);
    BookingBuilder date(String date);
    BookingBuilder duration(int duration);
    Booking build();
}
