/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Stage2;

/**
 *
 * @author lunas
 */
public class Booking {
    private Customer customer;
    private TourPackage tourPackage;
    private String date;
    private int duration;

    // Private constructor
    Booking(Customer customer, TourPackage tourPackage, String date, int duration) {
        this.customer = customer;
        this.tourPackage = tourPackage;
        this.date = date;
        this.duration = duration;
    }

    // Getters
    public Customer getCustomer() {
        return customer;
    }

    public TourPackage getTourPackage() {
        return tourPackage;
    }

    public String getDate() {
        return date;
    }

    public int getDuration() {
        return duration;
    }

    // Override toString() method to display booking details
    @Override
    public String toString() {
        return "Customer: " + customer.getName() + "\nTour Package: " + tourPackage.getPackageName() +
                "\nDate: " + date + "\nDuration: " + duration + " days";
    }

    // Static inner Builder class
    public static class BookingBuilder {
        private Customer customer;
        private TourPackage tourPackage;
        private String date;
        private int duration;

        public BookingBuilder() {}

        public BookingBuilder customer(Customer customer) {
            this.customer = customer;
            return this;
        }

        public BookingBuilder tourPackage(TourPackage tourPackage) {
            this.tourPackage = tourPackage;
            return this;
        }

        public BookingBuilder date(String date) {
            this.date = date;
            return this;
        }

        public BookingBuilder duration(int duration) {
            this.duration = duration;
            return this;
        }

        public Booking build() {
            return new Booking(customer, tourPackage, date, duration);
        }
    }
}
