/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Stage2;

/**
 *
 * @author lunas
 */
public class BookingDirector {
    private BookingBuilder builder;

    public BookingDirector(BookingBuilder builder) {
        this.builder = builder;
    }

    public Booking constructBooking(Customer customer, TourPackage tourPackage, String date, int duration) {
        return builder.customer(customer)
                .tourPackage(tourPackage)
                .date(date)
                .duration(duration)
                .build();
    }
}