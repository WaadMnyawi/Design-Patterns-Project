/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Stage2;

/**
 *
 * @author lunas
 */
public class TourPackage {
    private String packageName;
    private String description;
    private double price;

    public TourPackage(String packageName, String description, double price) {
        this.packageName = packageName;
        this.description = description;
        this.price = price;
    }

    public String getPackageName() {
        return packageName;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    // Override toString() method to display package details
    @Override
    public String toString() {
        return "Package: " + packageName + "\nDescription: " + description +
                "\nPrice: $" + price;
    }
}