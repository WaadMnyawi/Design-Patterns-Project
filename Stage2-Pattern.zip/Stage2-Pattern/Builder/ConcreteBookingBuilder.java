/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Stage2;

/**
 *
 * @author lunas
 */
public class ConcreteBookingBuilder implements BookingBuilder {
    private Customer customer;
    private TourPackage tourPackage;
    private String date;
    private int duration;

    @Override
    public BookingBuilder customer(Customer customer) {
        this.customer = customer;
        return this;
    }

    @Override
    public BookingBuilder tourPackage(TourPackage tourPackage) {
        this.tourPackage = tourPackage;
        return this;
    }

    @Override
    public BookingBuilder date(String date) {
        this.date = date;
        return this;
    }

    @Override
    public BookingBuilder duration(int duration) {
        this.duration = duration;
        return this;
    }

    @Override
    public Booking build() {
        return new Booking(customer, tourPackage, date, duration);
    }

}