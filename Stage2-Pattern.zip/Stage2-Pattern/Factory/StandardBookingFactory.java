/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Factory;



/**
 *
 * @author waadl
 */
class StandardBookingFactory implements BookingFactory {
    @Override
    public Booking createBooking(Customer customer, TourPackage tourPackage, String date, int duration) {
        return new Booking(customer, tourPackage, date, duration);
    }
}