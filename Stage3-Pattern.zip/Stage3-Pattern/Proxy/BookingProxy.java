/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proxy;

/**
 *
 * @author waadl
 */
public class BookingProxy implements Booking {
    private RealBooking realBooking;
    private String role;

    public BookingProxy(String role) {
        this.role = role;
    }

    @Override
    public void displayDetails() {
        if (role.equals("admin")) {
            // Create RealBooking only for admin
            if (realBooking == null) {
                realBooking = new RealBooking();
            }
            realBooking.displayDetails();
        } else {
            System.out.println("Access denied! You are not authorized to view booking details.");
        }
    }
}
