/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proxy;

/**
 *
 * @author waadl
 */
public class Main {
    public static void main(String[] args) {
        // Normal user trying to access booking details
        Booking normalUserBooking = new BookingProxy("user");
        normalUserBooking.displayDetails();

        // Admin accessing booking details
        Booking adminBooking = new BookingProxy("admin");
        adminBooking.displayDetails();
    }
}