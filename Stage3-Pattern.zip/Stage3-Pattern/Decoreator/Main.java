/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Decoreator;

/**
 *
 * @author waadl
 */
public class Main {
    public static void main(String[] args) {
        // Create a basic booking
        BookingComponent basicBooking = new Booking("Basic room booking");

        // Decorate the booking with meal service
        BookingComponent bookingWithMeal = new MealDecorator(basicBooking, "Breakfast");

        // Decorate the booking with Wifi service (for illustration purposes)
        BookingComponent bookingWithMealAndWifi = new WifiDecorator(bookingWithMeal);

        // Display booking details
        System.out.println("Booking details: " + bookingWithMealAndWifi.getDescription());
    }
}
