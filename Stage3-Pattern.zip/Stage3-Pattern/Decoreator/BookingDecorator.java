/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Decoreator;

/**
 *
 * @author waadl
 */
public abstract class BookingDecorator implements BookingComponent {
    protected BookingComponent bookingComponent;

    public BookingDecorator(BookingComponent bookingComponent) {
        this.bookingComponent = bookingComponent;
    }

    @Override
    public String getDescription() {
        return bookingComponent.getDescription();
    }

}
