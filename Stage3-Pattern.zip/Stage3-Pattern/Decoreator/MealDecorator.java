/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Decoreator;

/**
 *
 * @author waadl
 */
class MealDecorator extends BookingDecorator {
    private String meal;

    public MealDecorator(BookingComponent bookingComponent, String meal) {
        super(bookingComponent);
        this.meal = meal;
    }

   
    

    @Override
    public String getDescription() {
        return super.getDescription() + ", including meal: " + meal;
    }
}