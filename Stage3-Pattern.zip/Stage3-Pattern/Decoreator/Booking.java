/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Decoreator;

/**
 *
 * @author waadl
 */
public class Booking implements BookingComponent {
    private String description;

    public Booking(String description) {
        this.description = description;
    }

    @Override
    public String getDescription() {
        return description;
    }
}