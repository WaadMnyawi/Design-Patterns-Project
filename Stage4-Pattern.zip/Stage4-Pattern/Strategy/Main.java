/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Strategy;

/**
 *
 * @author waadl
 */
public class Main {
    public static void main(String[] args) {
        PaymentContext paymentContext = new PaymentContext() {
            private PaymentStrategy paymentStrategy;

            @Override
            public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
                this.paymentStrategy = paymentStrategy;
            }

            @Override
            public void processPayment(double amount) {
                if (paymentStrategy != null) {
                    paymentStrategy.processPayment(amount);
                } else {
                    System.out.println("No payment strategy set.");
                }
            }
        };

        // Set credit card payment strategy
        paymentContext.setPaymentStrategy(new CreditCardPaymentStrategy());
        paymentContext.processPayment(1000);

        // Set PayPal payment strategy
        paymentContext.setPaymentStrategy(new PayPalPaymentStrategy());
        paymentContext.processPayment(500);
    }
}