/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Observer;

/**
 *
 * @author waadl
 */
public class TravelAndTourManagementSystem {
    public static void main(String[] args) {
        Booking booking = new Booking(new Customer("tala","tala@gmail.com", "0500912345"), 
                                      new TourPackage("Package A", "Description A", 1000), 
                                      "2024-05-01", 3);

           // Attach observer
        Observer bookingObserver = new BookingObserver();
        booking.attach(bookingObserver);

        // Notify observers about the booking event
        booking.notifyObservers("Booking has been made:\n" + booking);
    }
}

