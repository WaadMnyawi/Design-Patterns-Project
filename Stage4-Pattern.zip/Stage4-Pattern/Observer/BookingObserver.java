/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Observer;

/**
 *
 * @author waadl
 */
public class BookingObserver implements Observer {
    @Override
    public void update(Object event) {
        System.out.println("Booking Observer: " + event);
    }
}