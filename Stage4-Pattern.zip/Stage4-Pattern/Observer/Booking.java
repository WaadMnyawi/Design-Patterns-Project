/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Observer;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author waadl
 */
public class Booking {
    private List<Observer> observers = new ArrayList<>();
    private Customer customer;
    private TourPackage tourPackage;
    private String date;
    private int duration;

    public Booking(Customer customer, TourPackage tourPackage, String date, int duration) {
        this.customer = customer;
        this.tourPackage = tourPackage;
        this.date = date;
        this.duration = duration;
    }

  

    // Getters for customer, tourPackage, date, duration
    public Customer getCustomer() {
        return customer;
    }

    public TourPackage getTourPackage() {
        return tourPackage;
    }

    public String getDate() {
        return date;
    }

    public int getDuration() {
        return duration;
    }

    // Observer methods
    public void attach(Observer observer) {
        observers.add(observer);
    }

    public void notifyObservers(Object event) {
        for (Observer observer : observers) {
            observer.update(event);
        }
    }

    // Override toString()
    @Override
    public String toString() {
        return "Customer: " + customer + "\n" +
               "Tour Package: " + tourPackage + "\n" +
               "Date: " + date + "\n" +
               "Duration: " + duration + " days";
    }
}
